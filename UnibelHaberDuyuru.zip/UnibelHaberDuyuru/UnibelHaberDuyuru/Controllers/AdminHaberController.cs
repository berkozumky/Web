﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnibelHaberDuyuru.Models;

namespace UnibelHaberDuyuru.Controllers
{
    public class AdminHaberController : Controller
    {
        private UnibelEntities db = new UnibelEntities();
        // GET: Admin
        public ActionResult Index()
        {
            var haberBilgi = db.HaberBilgi;
            return View(haberBilgi.ToList());
        }

        // GET: EtkinlikBilgileri/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HaberBilgi haberBilgi = db.HaberBilgi.Find(id);
            if (haberBilgi== null)
            {
                return HttpNotFound();
            }
            return View(haberBilgi);
        }

        // GET: EtkinlikBilgileri/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "HaberID,HaberADI,HaberRESIM,HaberACIKLAMA")] HaberBilgi haberBilgi)
        {
            if (ModelState.IsValid)
            {
                db.HaberBilgi.Add(haberBilgi);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(haberBilgi);
        }

        // GET: EtkinlikBilgileri/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HaberBilgi haberBilgi = db.HaberBilgi.Find(id);
            if (haberBilgi == null)
            {
                return HttpNotFound();
            }
            return View(haberBilgi);
        }

        // POST: HaberBilgi/Edit/5
        // Aşırı gönderim saldırılarından korunmak için bağlamak istediğiniz belirli özellikleri etkinleştirin. 
        // Daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "HaberID, HaberADI, HaberRESIM, HaberACIKLAMA")] HaberBilgi haberBilgi)
        {
            if (ModelState.IsValid)
            {
                db.Entry(haberBilgi).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(haberBilgi);
        }

        // GET: HaberBilgi/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HaberBilgi haberBilgi = db.HaberBilgi.Find(id);
            if (haberBilgi == null)
            {
                return HttpNotFound();
            }
            return View(haberBilgi);
        }

        // POST: HaberBilgi/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HaberBilgi haberBilgi = db.HaberBilgi.Find(id);
            db.HaberBilgi.Remove(haberBilgi);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}