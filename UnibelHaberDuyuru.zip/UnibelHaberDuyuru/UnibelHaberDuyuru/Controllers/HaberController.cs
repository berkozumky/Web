﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnibelHaberDuyuru.Models;

namespace UnibelHaberDuyuru.Controllers
{
    public class HaberController : Controller
    {
        // GET: Haber
        UnibelEntities db = new UnibelEntities();
        public ActionResult Index()
        {
            ViewModel vm = new ViewModel();
            vm.HABER = db.HaberBilgi.ToList();
            return View(vm);
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            HaberBilgi haber = db.HaberBilgi.FirstOrDefault(d => d.HaberID == id);

            if (haber == null)
            {
                return HttpNotFound();
            }
            return View(haber);
        }
    }
}