﻿using System.Linq;
using System.Web.Mvc;
using UnibelHaberDuyuru.Models;

namespace UnibelHaberDuyuru.Controllers
{
    public class AnaSayfaController : Controller
    {
        // GET: AnaSayfa
        UnibelEntities db = new UnibelEntities();
        public ActionResult Index()
        {
            ViewModel vm = new ViewModel();
            vm.HABER = db.HaberBilgi.ToList();
            vm.DUYURU = db.DuyuruBilgi.ToList();
            return View(vm);
        }
    }
}