﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnibelHaberDuyuru.Models;

namespace UnibelHaberDuyuru.Controllers
{
    public class DuyuruController : Controller
    {
        // GET: Duyuru
        UnibelEntities db = new UnibelEntities();
        public ActionResult Index()
        {
            ViewModel vm = new ViewModel();
            vm.DUYURU = db.DuyuruBilgi.ToList();
            return View(vm);
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            DuyuruBilgi duyuru = db.DuyuruBilgi.Find(id);

            if (duyuru == null)
            {
                return HttpNotFound();
            }
            return View(duyuru);
        }
    }
}