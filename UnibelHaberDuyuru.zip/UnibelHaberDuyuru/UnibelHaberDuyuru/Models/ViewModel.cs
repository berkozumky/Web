﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UnibelHaberDuyuru.Models
{
    public class ViewModel
    {
        public IEnumerable<HaberBilgi> HABER { get; set; }

        public IEnumerable<DuyuruBilgi> DUYURU { get; set; }
    }
}