using Microsoft.AspNetCore.Mvc;
using BoutiqueHotel.webUI.Models;
using BoutiqueHotel.webUI.Data;
using System.Linq;

namespace BoutiqueHotel.webUI.Controllers
{
    public class OrderController : Controller
    {

        public IActionResult List(int? id, string q)
        {

            var products = OrderRepository.Products;

            if (id != null)
            {
                products = products.Where(p => p.CategoryId == id).ToList();
            }
            if (!string.IsNullOrEmpty(q))
            {
                products = products.Where(i => i.Name.ToLower().Contains(q.ToLower()) || i.Description.ToLower().Contains(q.ToLower())).ToList();
            }

            var productViewModel = new ProductViewModel()
            {
                Products = products
            };

            return View(productViewModel);
        }

        public IActionResult Details(int id)
        {

            return View(OrderRepository.GetProductById(id));
        }
    }
}