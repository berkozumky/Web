using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using BoutiqueHotel.webUI.Models;

namespace BoutiqueHotel.webUI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

    }
}