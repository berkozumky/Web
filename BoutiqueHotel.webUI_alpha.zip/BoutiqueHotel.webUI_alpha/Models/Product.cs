using System.ComponentModel.DataAnnotations;

namespace BoutiqueHotel.webUI.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Lütfen, ürün ismi giriniz!..")]
        [StringLength(60, MinimumLength = 1)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Fiyat giriniz!..")]
        public double? Price { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage = "Lütfen, ürün resmi giriniz!..")]
        public string ImageUrl { get; set; }
        [Required]
        public int? CategoryId { get; set; }
    }
}