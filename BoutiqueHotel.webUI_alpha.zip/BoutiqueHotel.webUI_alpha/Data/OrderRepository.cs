using System.Collections.Generic;
using System.Linq;
using BoutiqueHotel.webUI.Models;

namespace BoutiqueHotel.webUI.Data
{
    public class OrderRepository
    {
        private static List<Product> _products = null;

        static OrderRepository()
        {
            _products = new List<Product>
            {
                new Product {ProductId=1,Name="Hamburger",Price=3000,Description="150 gr dana etli hamburger", ImageUrl="hamburger.jpg",CategoryId=1},
                new Product {ProductId=2,Name="Makarna",Price=4000,Description="Tavuk mantarlı penne", ImageUrl="makarna.jpg",CategoryId=1},
                new Product {ProductId=3,Name="Patates",Price=5000,Description="French Fries", ImageUrl="patates.jpg",CategoryId=1},
                new Product {ProductId=4,Name="Pizza",Price=7000,Description="Margarita", ImageUrl="pizza.jpg",CategoryId=1},
                new Product {ProductId=5,Name="Kola",Price=7000,Description="Coca-Cola", ImageUrl="kola.jpg",CategoryId=2},
                new Product {ProductId=6,Name="Gazoz",Price=7000,Description="Sprite", ImageUrl="sprite.jpg",CategoryId=2},
                new Product {ProductId=7,Name="Ayran",Price=7000,Description="SÜTAŞ AYRAN", ImageUrl="ayran.jpg",CategoryId=2},
                new Product {ProductId=8,Name="Limonata",Price=7000,Description="LİMONATA", ImageUrl="limonata.jpg",CategoryId=2},
                new Product {ProductId=9,Name="Dondurma",Price=7000,Description="KÜLAH DONDURMA", ImageUrl="dondurma.png",CategoryId=3},
                new Product {ProductId=10,Name="Waffle",Price=7000,Description="KARIŞIK", ImageUrl="waffle.jpg",CategoryId=3}
            };
        }

        public static List<Product> Products
        {
            get
            {
                return _products;
            }
        }

        public static void AddProduct(Product product)
        {
            _products.Add(product);
        }

        public static Product GetProductById(int id)
        {
            return _products.FirstOrDefault(p => p.ProductId == id);
        }
        public static void EditProduct(Product product)
        {
            foreach (var p in _products)
            {
                if (p.ProductId == product.ProductId)
                {
                    p.Name = product.Name;
                    p.Price = product.Price;
                    p.Description = product.Description;
                    p.ImageUrl = product.ImageUrl;
                    p.CategoryId = product.CategoryId;
                }
            }
        }

        public static void DeleteProduct(int id)
        {
            var product = GetProductById(id);

            if (product != null)
            {
                _products.Remove(product);
            }
        }
    }
}