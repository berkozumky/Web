using BoutiqueHotel.webUI.Data;
using BoutiqueHotel.webUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BoutiqueHotel.webUI.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Add()
        {
            ViewBag.Categories = new SelectList(CategoryRepository.Categories, "CategoryId", "Name");
            return View(new Product());
        }
        [HttpPost]
        public IActionResult Add(Product p)
        {
            if (ModelState.IsValid)
            {
                OrderRepository.AddProduct(p);
                return RedirectToAction("list", "order");
            }
            ViewBag.Categories = new SelectList(CategoryRepository.Categories, "CategoryId", "Name");
            return View(p);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Categories = new SelectList(CategoryRepository.Categories, "CategoryId", "Name");
            return View(OrderRepository.GetProductById(id));
        }
        [HttpPost]
        public IActionResult Edit(Product p)
        {
            if (ModelState.IsValid)
            {
                OrderRepository.EditProduct(p);
                return RedirectToAction("list", "order");
            }
            return View(p);
        }

        [HttpPost]
        public IActionResult delete(int ProductId)
        {
            OrderRepository.DeleteProduct(ProductId);
            return RedirectToAction("list", "order", "id");
        }
    }
}