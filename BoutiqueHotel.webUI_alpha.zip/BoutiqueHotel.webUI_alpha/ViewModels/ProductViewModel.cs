using System.Collections.Generic;
using BoutiqueHotel.webUI.Models;

public class ProductViewModel
{
    public List<Product> Products { get; set; }
}
