﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DFEtkinlik.Models;

namespace DFEtkinlik.Controllers
{
    public class EtkinlikBilgileriController : Controller
    {
        private etkinlikEntities db = new etkinlikEntities();

        // GET: EtkinlikBilgileri
        public ActionResult Index()
        {
            var etkinlikBilgileris = db.EtkinlikBilgileris.Include(e => e.EtkinlikTipleri).Include(e => e.EtkinlikYerleri);
            return View(etkinlikBilgileris.ToList());
        }

        // GET: EtkinlikBilgileri/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EtkinlikBilgileri etkinlikBilgileri = db.EtkinlikBilgileris.Find(id);
            if (etkinlikBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(etkinlikBilgileri);
        }

        // GET: EtkinlikBilgileri/Create
        public ActionResult Create()
        {
            ViewBag.EtkinlikTipiID = new SelectList(db.EtkinlikTipleris, "EtkinlikTipiID", "EtkinlikTipAdi");
            ViewBag.EtkinlikYerID = new SelectList(db.EtkinlikYerleris, "EtkinlikYerID", "EtkinlikYeri");
            return View();
        }

        // POST: EtkinlikBilgileri/Create
        // Aşırı gönderim saldırılarından korunmak için bağlamak istediğiniz belirli özellikleri etkinleştirin. 
        // Daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EtkinlikID,EtkinlikTipiID,EtkinlikYerID,EtkinlikAdi,EtkinlikAciklama,EtkinlikTarihi,EtkinlikSanatcisi")] EtkinlikBilgileri etkinlikBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.EtkinlikBilgileris.Add(etkinlikBilgileri);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EtkinlikTipiID = new SelectList(db.EtkinlikTipleris, "EtkinlikTipiID", "EtkinlikTipAdi", etkinlikBilgileri.EtkinlikTipiID);
            ViewBag.EtkinlikYerID = new SelectList(db.EtkinlikYerleris, "EtkinlikYerID", "EtkinlikYeri", etkinlikBilgileri.EtkinlikYerID);
            return View(etkinlikBilgileri);
        }

        // GET: EtkinlikBilgileri/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EtkinlikBilgileri etkinlikBilgileri = db.EtkinlikBilgileris.Find(id);
            if (etkinlikBilgileri == null)
            {
                return HttpNotFound();
            }
            ViewBag.EtkinlikTipiID = new SelectList(db.EtkinlikTipleris, "EtkinlikTipiID", "EtkinlikTipAdi", etkinlikBilgileri.EtkinlikTipiID);
            ViewBag.EtkinlikYerID = new SelectList(db.EtkinlikYerleris, "EtkinlikYerID", "EtkinlikYeri", etkinlikBilgileri.EtkinlikYerID);
            return View(etkinlikBilgileri);
        }

        // POST: EtkinlikBilgileri/Edit/5
        // Aşırı gönderim saldırılarından korunmak için bağlamak istediğiniz belirli özellikleri etkinleştirin. 
        // Daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EtkinlikID,EtkinlikTipiID,EtkinlikYerID,EtkinlikAdi,EtkinlikAciklama,EtkinlikTarihi,EtkinlikSanatcisi")] EtkinlikBilgileri etkinlikBilgileri)
        {
            if (ModelState.IsValid)
            {
                db.Entry(etkinlikBilgileri).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EtkinlikTipiID = new SelectList(db.EtkinlikTipleris, "EtkinlikTipiID", "EtkinlikTipAdi", etkinlikBilgileri.EtkinlikTipiID);
            ViewBag.EtkinlikYerID = new SelectList(db.EtkinlikYerleris, "EtkinlikYerID", "EtkinlikYeri", etkinlikBilgileri.EtkinlikYerID);
            return View(etkinlikBilgileri);
        }

        // GET: EtkinlikBilgileri/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EtkinlikBilgileri etkinlikBilgileri = db.EtkinlikBilgileris.Find(id);
            if (etkinlikBilgileri == null)
            {
                return HttpNotFound();
            }
            return View(etkinlikBilgileri);
        }

        // POST: EtkinlikBilgileri/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EtkinlikBilgileri etkinlikBilgileri = db.EtkinlikBilgileris.Find(id);
            db.EtkinlikBilgileris.Remove(etkinlikBilgileri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
